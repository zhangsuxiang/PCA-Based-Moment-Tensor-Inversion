"""
set_window.py

Window design for suppressing noise before and after the wavelet

This is the Python equivalent of set_window.m

Parameters:
    W1, W2 - times (in sec) defining the beginning of the window
    W3, W4 - times (in sec) defining the end of the window
    N - number of points of the window
    dt - sampling interval

Returns:
    window - the designed window array
"""

import numpy as np


def set_window(W1, W2, W3, W4, N, dt):
    """
    Design a window for suppressing noise before and after the wavelet
    
    The window has the following structure:
    - Zero before W1
    - Smooth rise from W1 to W2 (sin^2 taper)
    - One (pass) from W2 to W3
    - Smooth decay from W3 to W4 (cos^4 taper)
    - Zero after W4
    
    Args:
        W1 (float): Start time of the rising taper (sec)
        W2 (float): End time of the rising taper (sec)
        W3 (float): Start time of the falling taper (sec)
        W4 (float): End time of the falling taper (sec)
        N (int): Number of points in the window
        dt (float): Sampling interval (sec)
        
    Returns:
        window (numpy.ndarray): Window array of length N
    """
    # Time vector
    t = np.arange(N) * dt
    
    # Indexes of the weighting window
    i_W1 = int(round(W1 / dt))
    i_W2 = int(round(W2 / dt))
    i_W3 = int(round(W3 / dt))
    i_W4 = int(round(W4 / dt))
    
    # Initialize window
    window = np.zeros(N)
    
    # Setting the window
    # Zero before W1
    if i_W1 > 0:
        window[0:i_W1] = 0
    
    # Rising taper from W1 to W2 (sin^2)
    if i_W2 > i_W1:
        t_segment = t[i_W1:i_W2+1]
        window[i_W1:i_W2+1] = np.sin((t_segment - W1) / (W2 - W1) * np.pi / 2) ** 2
    
    # Pass band from W2 to W3
    if i_W3 > i_W2:
        window[i_W2+1:i_W3] = 1
    
    # Falling taper from W3 to W4 (cos^4)
    if i_W4 >= i_W3:
        t_segment = t[i_W3:i_W4+1]
        window[i_W3:i_W4+1] = np.cos((t_segment - W3) / (W4 - W3) * np.pi / 2) ** 4
    
    # Zero after W4
    if i_W4 < N:
        window[i_W4+1:N] = 0
    
    return window


def test_window():
    """
    Test function to visualize the window
    """
    import matplotlib.pyplot as plt
    
    # Test parameters
    W1 = 0.5
    W2 = 1.0
    W3 = 3.0
    W4 = 3.5
    N = 5000
    dt = 0.001
    
    # Create window
    window = set_window(W1, W2, W3, W4, N, dt)
    
    # Plot
    t = np.arange(N) * dt
    plt.figure(figsize=(10, 6))
    plt.plot(t, window, 'b-', linewidth=2)
    plt.axvline(W1, color='r', linestyle='--', alpha=0.5, label='W1')
    plt.axvline(W2, color='g', linestyle='--', alpha=0.5, label='W2')
    plt.axvline(W3, color='orange', linestyle='--', alpha=0.5, label='W3')
    plt.axvline(W4, color='purple', linestyle='--', alpha=0.5, label='W4')
    plt.xlabel('Time (s)')
    plt.ylabel('Window amplitude')
    plt.title('Window Function for Noise Suppression')
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.ylim([-0.1, 1.1])
    plt.tight_layout()
    plt.show()
    
    print(f"Window created with {N} points")
    print(f"W1={W1}, W2={W2}, W3={W3}, W4={W4}")
    print(f"Sampling interval: {dt} s")
    print(f"Window range: [{np.min(window):.3f}, {np.max(window):.3f}]")


if __name__ == "__main__":
    test_window()