"""
PCA_wavelet.py

Main code for the Principal Component Analysis of seismic records

Input files:
    configuration_PCA.py - control parameters for the PCA decomposition
    event_list.txt - ASCII file with the information about individual events

Details of the method can be found in:
    Vavrycuk, V., Adamova, P., Doubravova, J., Jakoubkova, H., 2017
    Moment tensor inversion based on the principal component analysis
    of waveforms: Method and application to microearthquakes in West
    Bohemia, Czech Republic, Seismological Research Letters

Version: 1.0 (Python)
Last update: 2025
Author: Python conversion of MATLAB code by V. Vavrycuk

Copyright:
    The rights to the software are owned by V. Vavrycuk. The code can be
    freely used for research purposes. The use of the software for
    commercial purposes with no commercial licence is prohibited.
"""

import numpy as np
import matplotlib.pyplot as plt
from scipy import signal, interpolate
from scipy.io import loadmat
from sklearn.decomposition import PCA as sklearn_PCA
import os
import warnings

# Import configuration and utility functions
from configuration_PCA import *
from set_window import set_window


def read_event_list(event_list_path):
    """
    Read event list from text file
    
    Returns:
        event_names, W1, W2, W3, W4, fr_low, fr_high, reference_station, reference_polarity
    """
    event_names = []
    W1 = []
    W2 = []
    W3 = []
    W4 = []
    fr_low = []
    fr_high = []
    reference_station = []
    reference_polarity = []
    
    with open(event_list_path, 'r') as f:
        for line in f:
            # Skip comments (lines starting with %)
            if line.strip().startswith('%') or not line.strip():
                continue
                
            parts = line.strip().split()
            if len(parts) >= 9:
                event_names.append(parts[0])
                W1.append(float(parts[1]))
                W2.append(float(parts[2]))
                W3.append(float(parts[3]))
                W4.append(float(parts[4]))
                fr_low.append(float(parts[5]))
                fr_high.append(float(parts[6]))
                reference_station.append(parts[7])
                reference_polarity.append(float(parts[8]))
    
    return (np.array(event_names), np.array(W1), np.array(W2), np.array(W3), 
            np.array(W4), np.array(fr_low), np.array(fr_high), 
            np.array(reference_station), np.array(reference_polarity))


def pca_decomposition(data):
    """
    Perform PCA decomposition on input data (matching MATLAB's pca function)
    
    Args:
        data: N_points x N_traces matrix
        
    Returns:
        coeff: PCA coefficients/scores (N_traces x N_components)
        principal_components: Principal components (N_points x N_components)
    
    MATLAB's pca returns:
        [coeff, score] = pca(X)
        - coeff: principal component coefficients (eigenvectors) - columns are PCs
        - score: principal component scores (X projected onto PCs)
    
    In our notation:
        - coeff corresponds to coefficients for reconstructing data
        - principal_components are the scores (projections)
    """
    # Center the data (subtract mean of each column)
    data_mean = np.mean(data, axis=0)
    data_centered = data - data_mean
    
    # Compute covariance matrix of centered data
    # Note: MATLAB uses cov(X) where X is N x p, returns p x p
    cov_matrix = np.cov(data_centered.T)
    
    # Eigenvalue decomposition
    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
    
    # Sort in descending order
    idx = eigenvalues.argsort()[::-1]
    eigenvalues = eigenvalues[idx]
    eigenvectors = eigenvectors[:, idx]
    
    # Compute principal components (scores): project data onto eigenvectors
    principal_components = data_centered @ eigenvectors
    
    # Coefficients are the eigenvectors (for reconstruction)
    coeff = eigenvectors
    
    return coeff, principal_components


def align_traces_by_cross_correlation(data, reference_trace, it_shift_limit):
    """
    Align traces using cross-correlation
    
    Args:
        data: N_points x N_traces matrix
        reference_trace: reference trace for alignment
        it_shift_limit: maximum shift in samples
        
    Returns:
        data_shifted: aligned data
        it_shift: shift values for each trace
    """
    N_points, N_traces = data.shape
    data_shifted = np.zeros_like(data)
    it_shift = np.zeros(N_traces, dtype=int)
    
    for j in range(N_traces):
        # Cross-correlation
        x_correlation = signal.correlate(data[:, j], reference_trace, mode='full')
        
        # Normalize
        norm1 = np.sqrt(np.sum(data[:, j]**2))
        norm2 = np.sqrt(np.sum(reference_trace**2))
        if norm1 > 0 and norm2 > 0:
            x_correlation = x_correlation / (norm1 * norm2)
        
        # Find maximum in the allowed range
        center_idx = N_points - 1
        start_idx = center_idx - it_shift_limit
        end_idx = center_idx + it_shift_limit + 1
        
        segment = x_correlation[start_idx:end_idx]
        max_idx = np.argmax(np.abs(segment))
        it_shift[j] = max_idx - it_shift_limit
    
    # Align traces
    for j in range(N_traces):
        if it_shift[j] >= 0:
            data_shifted[0:N_points-it_shift[j], j] = data[it_shift[j]:N_points, j]
        else:
            s = abs(it_shift[j])
            data_shifted[s:N_points, j] = data[0:N_points - s, j]
    
    return data_shifted, it_shift


def main():
    """
    Main function for PCA wavelet decomposition
    """
    print("="*70)
    print("PCA-DECOMPOSITION: Principal Component Analysis of Seismic Waveforms")
    print("="*70)
    
    # Check if event list exists
    if not os.path.exists(event_list):
        print(f"Error: {event_list} file not found")
        return
    
    # Read event parameters
    (event_names, W1, W2, W3, W4, fr_low, fr_high, 
     reference_station, reference_polarity) = read_event_list(event_list)
    
    # Number of events
    N_events = len(event_names)
    print(f"\nNumber of events to process: {N_events}")
    print("="*70)
    
    # Loop over events
    for i_event in range(N_events):
        print(f"\nProcessing event {i_event+1}/{N_events}: {event_names[i_event]}")
        print("-"*70)
        
        # Polarity of the reference station
        polarity_0 = reference_polarity[i_event]
        
        # Name of the analyzed event
        event_name = event_names[i_event]
        
        # ----------------------------------------------------------------
        # Read the data
        # ----------------------------------------------------------------
        event_path_name = os.path.join(data_path, event_name + '.mat')
        
        if not os.path.exists(event_path_name):
            print(f"Warning: Data file {event_path_name} not found. Skipping...")
            continue
        
        # Load MATLAB file
        mat_data = loadmat(event_path_name)
        event_data = mat_data['event_data']
        
        # Extract data fields
        stations = [str(s[0]) for s in event_data['stations'][0, 0][0]]
        orig_data = event_data['traces'][0, 0]
        dt_orig = float(event_data['sampling_rate'][0, 0][0, 0])
        
        N_points_orig, N_traces = orig_data.shape
        upsampling_order = int(round(dt_orig / dt))
        
        print(f"  Stations: {N_traces}")
        print(f"  Original sampling rate: {dt_orig} s")
        print(f"  Upsampling order: {upsampling_order}")
        
        # ----------------------------------------------------------------
        # Find the trace of the reference station
        # ----------------------------------------------------------------
        ref_station = reference_station[i_event]
        try:
            j0 = stations.index(ref_station)
        except ValueError:
            print(f"Warning: No velocity record for reference station {ref_station}")
            continue
        
        print(f"  Reference station: {ref_station} (index {j0})")
        
        # ----------------------------------------------------------------
        # Upsampling of the data
        # ----------------------------------------------------------------
        resampled_data = np.zeros((N_points_orig * upsampling_order, N_traces))
        
        for j in range(N_traces):
            # Use scipy interpolation (equivalent to MATLAB interp)
            x_old = np.arange(N_points_orig)
            x_new = np.linspace(0, N_points_orig - 1, N_points_orig * upsampling_order)
            f = interpolate.interp1d(x_old, orig_data[:, j], kind='linear')
            resampled_data[:, j] = f(x_new)
        
        # New sampling rate
        dt_new = dt_orig / upsampling_order
        N_points = resampled_data.shape[0]
        
        # ----------------------------------------------------------------
        # Remove offset (detrend constant)
        # ----------------------------------------------------------------
        for j in range(N_traces):
            resampled_data[:, j] = signal.detrend(resampled_data[:, j], type='constant')
        
        # ----------------------------------------------------------------
        # Integration to displacement (if requested)
        # ----------------------------------------------------------------
        if i_int:
            from scipy.integrate import cumulative_trapezoid
            resampled_data = cumulative_trapezoid(resampled_data, dx=dt_new, 
                                                   axis=0, initial=0)
        
        # ----------------------------------------------------------------
        # Band-pass filtering using the Butterworth filter
        # ----------------------------------------------------------------
        # Design filters
        b1, a1 = signal.butter(filter_order, fr_low[i_event] / f_Nyquist, 
                               btype='high')
        b2, a2 = signal.butter(filter_order, fr_high[i_event] / f_Nyquist, 
                               btype='low')
        
        # Filtering of the signal
        filtered_data = np.zeros_like(resampled_data)
        
        if i_zero_phase:
            # Zero-phase filtering (filtfilt)
            for j in range(N_traces):
                filtered_data_temp = signal.filtfilt(b1, a1, resampled_data[:, j])
                filtered_data[:, j] = signal.filtfilt(b2, a2, filtered_data_temp)
        else:
            # Regular filtering
            for j in range(N_traces):
                filtered_data_temp = signal.lfilter(b1, a1, resampled_data[:, j])
                filtered_data[:, j] = signal.lfilter(b2, a2, filtered_data_temp)
        
        print(f"  Frequency band: {fr_low[i_event]:.2f} - {fr_high[i_event]:.2f} Hz")
        
        # ----------------------------------------------------------------
        # Suppressing noise before and after the wavelet
        # ----------------------------------------------------------------
        # Window design
        window = set_window(W1[i_event], W2[i_event], W3[i_event], 
                           W4[i_event], N_points, dt_new)
        
        filtered_data_weighted = filtered_data * window[:, np.newaxis]
        
        # ----------------------------------------------------------------
        # Alignment of filtered traces by cross-correlation
        # ----------------------------------------------------------------
        print("  Performing first alignment by cross-correlation...")
        
        filtered_data_shifted, it_shift = align_traces_by_cross_correlation(
            filtered_data_weighted, filtered_data_weighted[:, j0], it_shift_limit
        )
        
        # Update filtered_data_shifted to use unweighted but shifted filtered_data
        filtered_data_shifted = np.zeros_like(filtered_data)
        for j in range(N_traces):
            if it_shift[j] >= 0:
                filtered_data_shifted[0:N_points-it_shift[j], j] = \
                    filtered_data[it_shift[j]:N_points, j]
            else:
                s = abs(it_shift[j])
                filtered_data_shifted[s:N_points, j] = filtered_data[0:N_points - s, j]
        
        # ----------------------------------------------------------------
        # Suppressing noise before and after the wavelet
        # ----------------------------------------------------------------
        filtered_data_weighted = filtered_data_shifted * window[:, np.newaxis]
        
        # ----------------------------------------------------------------
        # Principal component analysis: first step
        # ----------------------------------------------------------------
        print("  Performing PCA: first step...")
        
        data = filtered_data_weighted.copy()
        coeff, principal_components = pca_decomposition(data)
        principal_component = principal_components[:, 0]
        
        # ----------------------------------------------------------------
        # Alignment of filtered traces by cross-correlation with PCA wavelet
        # ----------------------------------------------------------------
        print("  Performing second alignment with PCA wavelet...")
        
        data_shifted, it_shift = align_traces_by_cross_correlation(
            data, principal_component, it_shift_limit
        )
        
        # Also shift the filtered_data_shifted
        filtered_src = filtered_data_shifted.copy()
        
        for j in range(N_traces):
            s = int(it_shift[j])
            # 保险：限制 s 不超过数组长度
            if s >= 0:
                if s > N_points: s = N_points
                # 长度 = N_points - s
                data_shifted[0:N_points - s, j] = data[s:N_points, j]
                filtered_data_shifted[0:N_points - s, j] = filtered_src[s:N_points, j]
                # 其余填零（可选，保持整洁）
                if s > 0:
                    data_shifted[N_points - s:N_points, j] = 0
                    filtered_data_shifted[N_points - s:N_points, j] = 0
            else:
                s = -s
                if s > N_points: s = N_points
                # 长度 = N_points - s
                data_shifted[s:N_points, j] = data[0:N_points - s, j]
                filtered_data_shifted[s:N_points, j] = filtered_src[0:N_points - s, j]
                # 其余填零（可选）
                if s > 0:
                    data_shifted[0:s, j] = 0
                    filtered_data_shifted[0:s, j] = 0
        
        # ----------------------------------------------------------------
        # Principal component analysis: second step
        # ----------------------------------------------------------------
        print("  Performing PCA: second step...")
        
        coeff, principal_components = pca_decomposition(data_shifted)
        
        # Selecting two most important principal components
        coeff_data = coeff[:, 0:2]
        principal_component = principal_components[:, 0]
        
        # Norm of the first principal component
        norm_pca = np.max(np.abs(principal_component))
        
        # First and second normalized principal components
        principal_components = principal_components / norm_pca
        
        # First normalized principal component
        principal_component = principal_component / norm_pca
        
        # PCA amplitudes
        amplitudes_pca = coeff_data[:, 0] * norm_pca
        
        # ----------------------------------------------------------------
        # Determine the polarity
        # ----------------------------------------------------------------
        polarity_pca = np.sign(amplitudes_pca)
        
        if polarity_pca[j0] != polarity_0:
            principal_component = -principal_component
            amplitudes_pca = -amplitudes_pca
            polarity_pca = -polarity_pca
        
        print(f"  PCA amplitudes range: [{np.min(amplitudes_pca):.2e}, "
              f"{np.max(amplitudes_pca):.2e}]")
        
        # ----------------------------------------------------------------
        # Plot figures
        # ----------------------------------------------------------------
        if i_plot:
            print("  Generating figures...")
            
            # Time vector
            t_vec = t[:N_points]
            
            # ------------------------------------------------------------------
            # Plot of original and filtered traces
            # ------------------------------------------------------------------
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 8))
            
            # Left plot: Original records
            if i_int:
                ax1.set_title('Original displacement records')
            else:
                ax1.set_title('Original velocity records')
            ax1.set_xlabel('Time (sec)')
            ax1.set_ylabel('Traces')
            
            for k in range(N_traces):
                trace_segment = resampled_data[it_min_show:it_max_show, k]
                max_val = np.max(np.abs(trace_segment))
                if max_val > 0:
                    normalized = trace_segment / (2.1 * max_val) + (k + 1)
                    ax1.plot(t_vec[it_min_show:it_max_show], normalized)
            
            ax1.set_xlim([t_min_show, t_max_show])
            y_lim = ax1.get_ylim()
            ax1.plot([W2[i_event], W2[i_event]], y_lim, '-k')
            ax1.plot([W3[i_event], W3[i_event]], y_lim, '-k')
            ax1.grid(True, alpha=0.3)
            
            # Right plot: Filtered weighted records
            ax2.set_title('Filtered weighted records')
            ax2.set_xlabel('Time (sec)')
            ax2.set_ylabel('Traces')
            
            for k in range(N_traces):
                trace_segment = data_shifted[it_min_show:it_max_show, k]
                max_val = np.max(np.abs(trace_segment))
                if max_val > 0:
                    normalized = polarity_pca[k] * trace_segment / (2.1 * max_val) + (k + 1)
                    ax2.plot(t_vec[it_min_show:it_max_show], normalized)
            
            ax2.set_xlim([t_min_show, t_max_show])
            y_lim = ax2.get_ylim()
            ax2.plot([W2[i_event], W2[i_event]], y_lim, '-k')
            ax2.plot([W3[i_event], W3[i_event]], y_lim, '-k')
            ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            if i_plot_save:
                figure_name = os.path.join(figure_path, f"{event_name}_data.png")
                plt.savefig(figure_name, dpi=300, bbox_inches='tight')
                print(f"    Saved: {figure_name}")
            
            # ------------------------------------------------------------------
            # Plot of principal components
            # ------------------------------------------------------------------
            fig, ax = plt.subplots(1, 1, figsize=(10, 6))
            ax.set_title('Components PC1 and PC2')
            ax.set_xlabel('Time (sec)')
            ax.set_ylabel('Amplitude')
            
            ax.plot(t_vec[:it_max_show], principal_components[:it_max_show, 0], 
                   'r', linewidth=2, label='PC1')
            ax.plot(t_vec[:it_max_show], principal_components[:it_max_show, 1], 
                   'k', linewidth=1.5, label='PC2')
            ax.set_xlim([t_min_show, t_max_show])
            ax.legend()
            ax.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            if i_plot_save:
                figure_name = os.path.join(figure_path, f"{event_name}_pc.png")
                plt.savefig(figure_name, dpi=300, bbox_inches='tight')
                print(f"    Saved: {figure_name}")
            
            # ------------------------------------------------------------------
            # Plot of traces together with principal components
            # ------------------------------------------------------------------
            fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6))
            
            # Left plot: Whole traces and PC1
            ax1.set_title('Whole traces and PC1')
            ax1.set_xlabel('Time (sec)')
            ax1.set_ylabel('Amplitude')
            
            # Normalize traces
            data_shifted_weighted = np.zeros_like(data_shifted)
            filtered_data_shifted_normalized = np.zeros_like(filtered_data_shifted)
            
            for j in range(N_traces):
                max_val = np.max(np.abs(data_shifted[:, j]))
                if max_val > 0:
                    data_shifted_weighted[:, j] = \
                        data_shifted[:, j] * polarity_pca[j] / max_val
                
                scale = np.max(np.abs(filtered_data_shifted[:, j] * window))
                if scale > 0:
                    filtered_data_shifted_normalized[:, j] = \
                        filtered_data_shifted[:, j] * polarity_pca[j] / scale
            
            ax1.plot(t_vec, filtered_data_shifted_normalized, '-b', alpha=0.5)
            pc1_normalized = principal_component[:it_max_show] / \
                            np.max(np.abs(principal_component))
            ax1.plot(t_vec[:it_max_show], pc1_normalized, '-r', linewidth=2)
            ax1.plot([W2[i_event], W2[i_event]], [-1, 1], '-k')
            ax1.plot([W3[i_event], W3[i_event]], [-1, 1], '-k')
            ax1.set_xlim([t_min_show, t_max_show])
            ax1.set_ylim([-1, 1])
            ax1.grid(True, alpha=0.3)
            
            # Right plot: Windowed traces and PC1
            ax2.set_title('Windowed traces and PC1')
            ax2.set_xlabel('Time (sec)')
            ax2.set_ylabel('Amplitude')
            
            ax2.plot(t_vec, data_shifted_weighted, '-b', alpha=0.5)
            ax2.plot(t_vec[:it_max_show], pc1_normalized, '-r', linewidth=2)
            ax2.plot([W2[i_event], W2[i_event]], [-1, 1], '-k')
            ax2.plot([W3[i_event], W3[i_event]], [-1, 1], '-k')
            ax2.set_xlim([t_min_show, t_max_show])
            ax2.set_ylim([-1, 1])
            ax2.grid(True, alpha=0.3)
            
            plt.tight_layout()
            
            if i_plot_save:
                figure_name = os.path.join(figure_path, f"{event_name}_data_pc.png")
                plt.savefig(figure_name, dpi=300, bbox_inches='tight')
                print(f"    Saved: {figure_name}")
            
            if not i_plot_save:
                plt.show()
            else:
                plt.close('all')
        
        # ----------------------------------------------------------------
        # Saving the results
        # ----------------------------------------------------------------
        print("  Saving results...")
        
        # PCA amplitudes
        output_file_amplitudes = os.path.join(output_path, 
                                             f"{event_name}_pca_amplitudes.txt")
        
        with open(output_file_amplitudes, 'w') as f:
            for i in range(N_traces):
                f.write(f"{stations[i]} {amplitudes_pca[i]:.6e}\n")
        
        print(f"    Saved: {output_file_amplitudes}")
        
        # PCA wavelet
        output_file_wavelet = os.path.join(output_path, f"{event_name}_wavelet.txt")
        
        with open(output_file_wavelet, 'w') as f:
            for i in range(N_points):
                f.write(f"{t_vec[i]:.6f} {principal_component[i]:.6e}\n")
        
        print(f"    Saved: {output_file_wavelet}")
        
        print(f"  Event {event_name} processed successfully!")
        print("-"*70)
    
    print("\n" + "="*70)
    print("All events processed!")
    print("="*70)


if __name__ == "__main__":
    main()