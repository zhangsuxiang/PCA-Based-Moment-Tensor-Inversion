"""
configuration_PCA.py

File with control parameters of the Principal Component analysis
of seismograms

This is the Python equivalent of configuration_PCA.m
"""

import numpy as np
import os

# --------------------------------------------------------------------------
# Parameters for preprocessing of seismic traces
# --------------------------------------------------------------------------

# Time window for plotting (in sec)
t_min_show = 1.0
t_max_show = 3.0

# Sampling interval after upsampling
dt = 1e-3

# Maximum number of samples
N = 10000

# Maximum alignment shift in [sec]
t_shift_limit = 0.07

# Integrate the velocity to displacement
# (1: integrate, 0: do not integrate)
i_int = 0

# Use zero-phase filter
# (1: use zero-phase filtration, 0: do not use zero-phase filter)
i_zero_phase = 1

# --------------------------------------------------------------------------
# Control parameters for outputs
# --------------------------------------------------------------------------

# Plot figures (1: plot figures or 0: do not plot figures)
i_plot = 1

# Save figures (1: save figures or 0: do not save figures)
i_plot_save = 1

# --------------------------------------------------------------------------
# Paths
# --------------------------------------------------------------------------

# Specify the event list
event_list = '../Data/event_list.txt'

# Specify the path to data file
data_path = '../Data/Events/'

# Specify the output path
output_path = '../Output/'

# Specify the figures path
figure_path = '../Figures/'

# The path to programs
program_path = os.getcwd()

# --------------------------------------------------------------------------
# Other auxiliary parameters calculated from the control parameters
# --------------------------------------------------------------------------

# Order of the band-pass filter
filter_order = 4

# Frequency step
df = 1 / (N * dt)

# Time scale
i_scale = np.arange(1, N + 1)
t = (i_scale - 1) * dt

# Frequency scale
f = (i_scale - 1) * df

# Nyquist frequency
f_Nyquist = 1 / (2 * dt)

# Maximum frequency
f_max = 1 / dt

# Indexes of the displaying window
it_min_show = int(round(t_min_show / dt))
it_max_show = int(round(t_max_show / dt))

# Maximum alignment in samples
it_shift_limit = int(round(t_shift_limit / dt))

# Print configuration summary
if __name__ == "__main__":
    print("="*70)
    print("PCA Configuration Parameters")
    print("="*70)
    print(f"Time window for plotting: {t_min_show} - {t_max_show} s")
    print(f"Sampling interval: {dt*1000} ms")
    print(f"Maximum samples: {N}")
    print(f"Maximum alignment shift: {t_shift_limit} s ({it_shift_limit} samples)")
    print(f"Integration velocity->displacement: {'Yes' if i_int else 'No'}")
    print(f"Zero-phase filter: {'Yes' if i_zero_phase else 'No'}")
    print(f"Filter order: {filter_order}")
    print(f"Nyquist frequency: {f_Nyquist} Hz")
    print(f"Plot figures: {'Yes' if i_plot else 'No'}")
    print(f"Save figures: {'Yes' if i_plot_save else 'No'}")
    print("="*70)
    print("Paths:")
    print(f"  Event list: {event_list}")
    print(f"  Data path: {data_path}")
    print(f"  Output path: {output_path}")
    print(f"  Figure path: {figure_path}")
    print("="*70)