# 快速开始指南

## 安装

```bash
pip install -r requirements.txt
```

## 目录结构

请按以下结构组织文件：

```
your_project/
├── Programs/
│   ├── PCA_wavelet.py
│   ├── configuration_PCA.py
│   ├── set_window.py
│   
├── Data/
│   ├── event_list.txt
│   └── Events/
│       ├── event001.mat
│       ├── event002.mat
│       └── ...
├── Output/
│   └── (程序输出将保存在这里)
└── Figures/
    └── (图形将保存在这里)
```

## 配置参数

编辑 `configuration_PCA.py` 来调整参数：

```python
# 时间窗口
t_min_show = 1.0  # 绘图起始时间(秒)
t_max_show = 3.0  # 绘图结束时间(秒)

# 采样
dt = 1e-3  # 采样间隔(秒)

# 对齐
t_shift_limit = 0.07  # 最大时移(秒)

# 积分
i_int = 0  # 1=积分速度到位移, 0=不积分

# 滤波
i_zero_phase = 1  # 1=零相位滤波, 0=普通滤波

# 输出
i_plot = 1  # 1=绘图, 0=不绘图
i_plot_save = 1  # 1=保存图形, 0=不保存
```

## 准备事件列表

创建 `Data/event_list.txt`:

```
# 格式: EventID W1 W2 W3 W4 fr_low fr_high ref_station ref_polarity
event001 0.8 1.2 2.8 3.2 2.0 20.0 STA01 1
event002 0.9 1.3 2.7 3.1 2.0 20.0 STA02 -1
```

参数说明：
- `EventID`: 事件名称（需与.mat文件名匹配）
- `W1, W2`: 窗口上升沿时间(秒)
- `W3, W4`: 窗口下降沿时间(秒)
- `fr_low`: 高通滤波频率(Hz)
- `fr_high`: 低通滤波频率(Hz)
- `ref_station`: 参考台站名称
- `ref_polarity`: 参考台站极性(+1或-1)

## 准备数据文件

每个事件需要一个 `.mat` 文件，包含以下结构：

```python
# 使用scipy创建示例
from scipy.io import savemat
import numpy as np

event_data = {
    'stations': np.array([['STA01'], ['STA02'], ['STA03']]),  
    'traces': np.random.randn(10000, 3),  # N_points x N_stations
    'sampling_rate': 0.004  # 采样间隔(秒)
}

savemat('Data/Events/event001.mat', {'event_data': event_data})
```

## 运行程序

```bash
cd Programs
python PCA_wavelet.py
```

## 输出文件

程序为每个事件生成以下文件：

### 1. PCA振幅 (`event001_pca_amplitudes.txt`)
```
STA01 1.234567e-05
STA02 -2.345678e-05
STA03 3.456789e-05
```

### 2. PCA波形 (`event001_wavelet.txt`)
```
0.000000 0.000000e+00
0.001000 1.234567e-06
0.002000 2.345678e-06
...
```

### 3. 图形文件
- `event001_data.png`: 原始和滤波后的波形
- `event001_pc.png`: 主成分PC1和PC2
- `event001_data_pc.png`: 波形与主成分对比

## 读取输出结果

```python
import numpy as np

# 读取PCA振幅
data = np.loadtxt('Output/event001_pca_amplitudes.txt', 
                  dtype=[('station', 'U10'), ('amplitude', float)])
stations = data['station']
amplitudes = data['amplitude']

# 读取PCA波形
wavelet = np.loadtxt('Output/event001_wavelet.txt')
time = wavelet[:, 0]
wavelet_values = wavelet[:, 1]

# 绘图
import matplotlib.pyplot as plt
plt.figure(figsize=(10, 6))
plt.plot(time, wavelet_values, 'r-', linewidth=2)
plt.xlabel('Time (s)')
plt.ylabel('Amplitude')
plt.title('PCA Wavelet')
plt.grid(True)
plt.show()
```

## 验证安装

运行测试脚本验证安装：

```bash
python compare_matlab_python.py
```

应该看到：
```
🎉 All tests passed! Python implementation is equivalent to MATLAB.
```

## 常见问题

### Q1: ImportError: No module named 'scipy'
A: 安装依赖包：
```bash
pip install -r requirements.txt
```

### Q2: FileNotFoundError: event_list.txt
A: 确保：
1. 你在 `Programs/` 目录下运行程序
2. `Data/event_list.txt` 文件存在
3. 路径配置正确（检查 `configuration_PCA.py`）

### Q3: 结果与MATLAB不完全一致
A: 检查：
1. 采样率是否一致
2. 滤波器参数是否相同
3. 窗口参数是否正确
4. 是否使用零相位滤波

### Q4: 内存不足
A: 对于大数据集：
1. 减小 `N` 的值（最大采样点数）
2. 分批处理事件
3. 增加系统内存

## 高级用法

### 批量处理

创建批处理脚本：

```python
import os
import glob

# 查找所有.mat文件
mat_files = glob.glob('../Data/Events/*.mat')

# 为每个文件创建event_list条目
with open('../Data/event_list.txt', 'w') as f:
    f.write('# EventID W1 W2 W3 W4 fr_low fr_high ref_station ref_polarity\n')
    for mat_file in mat_files:
        event_name = os.path.basename(mat_file).replace('.mat', '')
        # 使用默认参数
        f.write(f'{event_name} 0.8 1.2 2.8 3.2 2.0 20.0 STA01 1\n')

# 运行PCA分析
os.system('python PCA_wavelet.py')
```

### 自定义处理

如需修改处理流程，编辑 `PCA_wavelet.py` 的相应部分。主要函数：
- `read_event_list()`: 读取事件参数
- `pca_decomposition()`: PCA分解
- `align_traces_by_cross_correlation()`: 波形对齐

## 性能优化建议

1. **使用零相位滤波**: 设置 `i_zero_phase = 1` 可获得更好的相位响应
2. **适当的滤波频率**: 根据信号特征调整 `fr_low` 和 `fr_high`
3. **窗口参数**: 确保窗口完全包含目标波形
4. **时移限制**: 设置合理的 `t_shift_limit` 以平衡精度和计算量

## 获取帮助

1. 查看 `README.md` 了解详细文档
2. 查看 `VERIFICATION_REPORT.md` 了解验证结果
3. 运行测试脚本排查问题
4. 查阅原始论文了解方法细节

## 下一步

- [ ] 准备您的数据
- [ ] 配置参数
- [ ] 运行测试
- [ ] 处理实际数据
- [ ] 分析结果

祝使用愉快！🎉